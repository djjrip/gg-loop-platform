GG LOOP ARCADE v1
======================

This is a demo build of the GG LOOP core loop, designed to be dropped straight into Replit.

What it includes
----------------
- Mock "win" flow that adds points based on tier.
- Tier system (Free/Basic/Pro/Elite) with monthly caps and points per win.
- Rewards catalog + redeem endpoint.
- Leaderboard API.
- Dashboard UI (dashboard.html).
- Profit safety calculator (profit.html).
- No real payments; everything is demo-safe.

How to run on Replit
--------------------
1. Create a new Node.js Repl.
2. Upload everything in this ZIP into the Repl.
3. In the Shell, run:
   npm install express express-session @replit/database node-fetch
   node server.js
4. Open the webview:
   - /        -> landing page
   - /dashboard.html -> main demo
   - /profit.html    -> profit calculator

In production you would:
- Replace /api/mock-win with real Henrik/Riot API based verification.
- Wire PayPal/Stripe webhooks to /api/set-tier.
- Move from Replit DB to Supabase/Postgres.

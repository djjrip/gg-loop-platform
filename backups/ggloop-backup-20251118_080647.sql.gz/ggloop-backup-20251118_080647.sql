--
-- PostgreSQL database dump
--

-- Dumped from database version 16.9 (415ebe8)
-- Dumped by pg_dump version 16.9

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: achievements; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.achievements (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    user_id character varying NOT NULL,
    game_id character varying NOT NULL,
    title text NOT NULL,
    description text,
    points_awarded integer NOT NULL,
    achieved_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.achievements OWNER TO neondb_owner;

--
-- Name: api_partners; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.api_partners (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    name text NOT NULL,
    description text,
    api_key character varying NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    webhook_url text,
    rate_limit integer DEFAULT 1000 NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    api_secret character varying NOT NULL
);


ALTER TABLE public.api_partners OWNER TO neondb_owner;

--
-- Name: audit_log; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.audit_log (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    admin_user_id character varying NOT NULL,
    admin_email character varying NOT NULL,
    action character varying NOT NULL,
    target_user_id character varying,
    details jsonb NOT NULL,
    ip_address character varying,
    "timestamp" timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.audit_log OWNER TO neondb_owner;

--
-- Name: challenge_completions; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.challenge_completions (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    user_id character varying NOT NULL,
    challenge_id character varying NOT NULL,
    progress integer DEFAULT 0 NOT NULL,
    completed_at timestamp without time zone,
    claimed boolean DEFAULT false NOT NULL,
    claimed_at timestamp without time zone,
    points_awarded integer NOT NULL,
    transaction_id character varying,
    fraud_check_passed boolean DEFAULT true,
    fraud_reason text,
    ip_address character varying,
    user_agent text,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    CONSTRAINT points_awarded_check CHECK ((points_awarded >= 0)),
    CONSTRAINT progress_check CHECK ((progress >= 0))
);


ALTER TABLE public.challenge_completions OWNER TO neondb_owner;

--
-- Name: challenges; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.challenges (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    title text NOT NULL,
    description text,
    sponsor_name character varying NOT NULL,
    sponsor_logo text,
    game_id character varying,
    requirement_type character varying NOT NULL,
    requirement_count integer NOT NULL,
    bonus_points integer NOT NULL,
    total_budget integer NOT NULL,
    points_distributed integer DEFAULT 0 NOT NULL,
    max_completions integer,
    current_completions integer DEFAULT 0 NOT NULL,
    start_date timestamp without time zone NOT NULL,
    end_date timestamp without time zone NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    sponsor_id character varying,
    CONSTRAINT budget_check CHECK ((points_distributed <= total_budget)),
    CONSTRAINT completions_check CHECK ((current_completions <= COALESCE(max_completions, current_completions))),
    CONSTRAINT positive_count_check CHECK (((requirement_count > 0) AND (bonus_points > 0) AND (total_budget > 0))),
    CONSTRAINT requirement_type_check CHECK (((requirement_type)::text = ANY ((ARRAY['match_wins'::character varying, 'hours_played'::character varying, 'rank_achieved'::character varying, 'achievement_unlock'::character varying])::text[])))
);


ALTER TABLE public.challenges OWNER TO neondb_owner;

--
-- Name: checklist_items; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.checklist_items (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    date character varying NOT NULL,
    task_id character varying NOT NULL,
    task_label text NOT NULL,
    completed boolean DEFAULT false NOT NULL,
    completed_at timestamp without time zone,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.checklist_items OWNER TO neondb_owner;

--
-- Name: games; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.games (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    title text NOT NULL,
    category text NOT NULL,
    image_url text NOT NULL,
    description text,
    players integer DEFAULT 0 NOT NULL,
    avg_score integer DEFAULT 0 NOT NULL,
    challenges integer DEFAULT 0 NOT NULL,
    is_active boolean DEFAULT true NOT NULL
);


ALTER TABLE public.games OWNER TO neondb_owner;

--
-- Name: gaming_events; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.gaming_events (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    partner_id character varying NOT NULL,
    user_id character varying,
    game_id character varying,
    event_type character varying NOT NULL,
    event_data jsonb,
    points_awarded integer,
    transaction_id character varying,
    external_event_id character varying NOT NULL,
    status character varying DEFAULT 'pending'::character varying NOT NULL,
    error_message text,
    retry_count integer DEFAULT 0 NOT NULL,
    processed_at timestamp without time zone,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.gaming_events OWNER TO neondb_owner;

--
-- Name: gg_coin_transactions; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.gg_coin_transactions (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    user_id character varying NOT NULL,
    amount integer NOT NULL,
    reason text NOT NULL,
    source_type character varying,
    source_id character varying,
    balance_after integer NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.gg_coin_transactions OWNER TO neondb_owner;

--
-- Name: leaderboard_entries; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.leaderboard_entries (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    user_id character varying NOT NULL,
    game_id character varying NOT NULL,
    score integer NOT NULL,
    rank integer NOT NULL,
    period text NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.leaderboard_entries OWNER TO neondb_owner;

--
-- Name: match_submissions; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.match_submissions (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    user_id character varying NOT NULL,
    game_id character varying NOT NULL,
    match_type character varying NOT NULL,
    notes text,
    screenshot_url text,
    status character varying DEFAULT 'pending'::character varying NOT NULL,
    points_awarded integer,
    reviewed_by character varying,
    review_notes text,
    submitted_at timestamp without time zone DEFAULT now() NOT NULL,
    reviewed_at timestamp without time zone,
    riot_match_id character varying,
    verified_via_riot boolean DEFAULT false,
    match_data jsonb
);


ALTER TABLE public.match_submissions OWNER TO neondb_owner;

--
-- Name: point_transactions; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.point_transactions (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    user_id character varying NOT NULL,
    amount integer NOT NULL,
    type character varying NOT NULL,
    source_id character varying,
    source_type character varying,
    description text,
    expires_at timestamp without time zone,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    balance_after integer NOT NULL,
    is_expired boolean DEFAULT false NOT NULL
);


ALTER TABLE public.point_transactions OWNER TO neondb_owner;

--
-- Name: processed_riot_matches; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.processed_riot_matches (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    riot_account_id character varying NOT NULL,
    match_id text NOT NULL,
    game_ended_at timestamp without time zone NOT NULL,
    is_win boolean NOT NULL,
    points_awarded integer NOT NULL,
    transaction_id character varying,
    processed_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.processed_riot_matches OWNER TO neondb_owner;

--
-- Name: referrals; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.referrals (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    referrer_id character varying NOT NULL,
    referred_user_id character varying NOT NULL,
    status character varying DEFAULT 'pending'::character varying NOT NULL,
    points_awarded integer DEFAULT 0,
    tier integer DEFAULT 0,
    completion_reason character varying,
    activated_at timestamp without time zone,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    completed_at timestamp without time zone
);


ALTER TABLE public.referrals OWNER TO neondb_owner;

--
-- Name: rewards; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.rewards (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    title text NOT NULL,
    description text,
    points_cost integer NOT NULL,
    image_url text,
    category text NOT NULL,
    in_stock boolean DEFAULT true NOT NULL,
    real_value integer NOT NULL,
    tier integer DEFAULT 1 NOT NULL,
    stock integer,
    sku character varying,
    fulfillment_type character varying DEFAULT 'manual'::character varying NOT NULL
);


ALTER TABLE public.rewards OWNER TO neondb_owner;

--
-- Name: riot_accounts; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.riot_accounts (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    user_id character varying NOT NULL,
    puuid text NOT NULL,
    game_name text NOT NULL,
    tag_line text NOT NULL,
    region character varying NOT NULL,
    game character varying NOT NULL,
    last_synced_at timestamp without time zone,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    CONSTRAINT riot_accounts_game_check CHECK (((game)::text = ANY ((ARRAY['league'::character varying, 'valorant'::character varying])::text[])))
);


ALTER TABLE public.riot_accounts OWNER TO neondb_owner;

--
-- Name: sessions; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.sessions (
    sid character varying NOT NULL,
    sess jsonb NOT NULL,
    expire timestamp without time zone NOT NULL
);


ALTER TABLE public.sessions OWNER TO neondb_owner;

--
-- Name: subscription_events; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.subscription_events (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    subscription_id character varying NOT NULL,
    event_type character varying NOT NULL,
    stripe_event_id character varying,
    event_data jsonb,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.subscription_events OWNER TO neondb_owner;

--
-- Name: subscriptions; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.subscriptions (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    user_id character varying NOT NULL,
    tier character varying DEFAULT 'basic'::character varying NOT NULL,
    status character varying DEFAULT 'active'::character varying NOT NULL,
    current_period_start timestamp without time zone NOT NULL,
    current_period_end timestamp without time zone NOT NULL,
    cancel_at timestamp without time zone,
    canceled_at timestamp without time zone,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    stripe_subscription_id character varying
);


ALTER TABLE public.subscriptions OWNER TO neondb_owner;

--
-- Name: user_badges; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.user_badges (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    user_id character varying NOT NULL,
    badge_id character varying NOT NULL,
    unlocked_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.user_badges OWNER TO neondb_owner;

--
-- Name: user_games; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.user_games (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    user_id character varying NOT NULL,
    game_id character varying NOT NULL,
    account_name text,
    connected_at timestamp without time zone DEFAULT now() NOT NULL,
    riot_puuid character varying(78),
    riot_game_name character varying,
    riot_tag_line character varying,
    riot_region character varying,
    steam_id character varying,
    verified_at timestamp without time zone,
    last_match_check timestamp without time zone
);


ALTER TABLE public.user_games OWNER TO neondb_owner;

--
-- Name: user_rewards; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.user_rewards (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    user_id character varying NOT NULL,
    reward_id character varying NOT NULL,
    redeemed_at timestamp without time zone DEFAULT now() NOT NULL,
    status text DEFAULT 'pending'::text NOT NULL,
    points_spent integer NOT NULL,
    fulfillment_data jsonb,
    tracking_number text,
    fulfillment_notes text,
    fulfilled_at timestamp without time zone,
    shipping_address text,
    shipping_city character varying,
    shipping_state character varying,
    shipping_zip character varying,
    shipping_country character varying
);


ALTER TABLE public.user_rewards OWNER TO neondb_owner;

--
-- Name: users; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.users (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    email character varying,
    total_points integer DEFAULT 0 NOT NULL,
    games_connected integer DEFAULT 0 NOT NULL,
    first_name character varying,
    last_name character varying,
    profile_image_url character varying,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now(),
    stripe_customer_id character varying,
    stripe_subscription_id character varying,
    oidc_sub character varying,
    username character varying(255),
    twitch_id character varying,
    twitch_username character varying,
    twitch_access_token text,
    twitch_refresh_token text,
    twitch_connected_at timestamp without time zone,
    referral_code character varying(10),
    referred_by character varying,
    free_trial_started_at timestamp without time zone,
    free_trial_ends_at timestamp without time zone,
    is_founder boolean DEFAULT false NOT NULL,
    founder_number integer,
    gg_coins integer DEFAULT 0 NOT NULL,
    login_streak integer DEFAULT 0 NOT NULL,
    longest_streak integer DEFAULT 0 NOT NULL,
    xp_level integer DEFAULT 1 NOT NULL,
    xp_points integer DEFAULT 0 NOT NULL,
    last_login_at timestamp without time zone,
    shipping_address text,
    shipping_city character varying,
    shipping_state character varying,
    shipping_zip character varying,
    shipping_country character varying DEFAULT 'US'::character varying
);


ALTER TABLE public.users OWNER TO neondb_owner;

--
-- Name: virtual_badges; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.virtual_badges (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    name text NOT NULL,
    description text NOT NULL,
    icon_url text,
    rarity character varying DEFAULT 'common'::character varying NOT NULL,
    unlock_condition text NOT NULL,
    gg_coins_required integer DEFAULT 0,
    gg_coins_reward integer DEFAULT 0 NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.virtual_badges OWNER TO neondb_owner;

--
-- Data for Name: achievements; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.achievements (id, user_id, game_id, title, description, points_awarded, achieved_at) FROM stdin;
\.


--
-- Data for Name: api_partners; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.api_partners (id, name, description, api_key, is_active, webhook_url, rate_limit, created_at, updated_at, api_secret) FROM stdin;
c4c1aacf-e429-4851-afd0-4684fe85219c	Test Gaming Platform	Test partner for HMAC validation	test_api_key_hmac	t	\N	1000	2025-11-09 08:17:58.07981	2025-11-09 08:17:58.07981	test_secret_hmac_123
\.


--
-- Data for Name: audit_log; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.audit_log (id, admin_user_id, admin_email, action, target_user_id, details, ip_address, "timestamp") FROM stdin;
\.


--
-- Data for Name: challenge_completions; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.challenge_completions (id, user_id, challenge_id, progress, completed_at, claimed, claimed_at, points_awarded, transaction_id, fraud_check_passed, fraud_reason, ip_address, user_agent, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: challenges; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.challenges (id, title, description, sponsor_name, sponsor_logo, game_id, requirement_type, requirement_count, bonus_points, total_budget, points_distributed, max_completions, current_completions, start_date, end_date, is_active, created_at, updated_at, sponsor_id) FROM stdin;
69a44300-6875-4c18-a298-7c1ca6e04053	Win 5 Matches - Earn 500 Bonus Points!	Complete 5 League of Legends match wins to unlock 500 bonus points (worth $5 in rewards). This bonus bypasses your monthly earning cap!	Riot Games	\N	\N	match_wins	5	500	50000	0	100	0	2025-11-11 00:38:29.850905	2025-12-11 00:38:29.850905	t	2025-11-11 00:38:29.850905	2025-11-11 00:38:29.850905	\N
\.


--
-- Data for Name: checklist_items; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.checklist_items (id, date, task_id, task_label, completed, completed_at, created_at) FROM stdin;
\.


--
-- Data for Name: games; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.games (id, title, category, image_url, description, players, avg_score, challenges, is_active) FROM stdin;
4cf0e30a-7969-4572-a8f5-29ad5935dc00	League of Legends	MOBA	https://images.unsplash.com/photo-1560253023-3ec5d502959f?w=800&q=80	Climb the ranked ladder and complete weekly challenges	67890	2100	32	t
36f728c6-8143-4be3-9e94-54c549a48d7f	Valorant	FPS	https://images.unsplash.com/photo-1598550476439-6847785fcea6?w=800&q=80	Tactical shooter with competitive gameplay and rewards	52100	1920	28	t
1ce197a8-1cd3-476e-a3f8-74f463675381	Counter-Strike 2	FPS	https://images.unsplash.com/photo-1542751371-adc38448a05e?w=800&q=80	Compete in ranked matches and earn points for your performance	45230	1850	24	f
7723c361-33ed-403b-8fa5-78b4eb78f427	Apex Legends	Battle Royale	https://images.unsplash.com/photo-1552820728-8b83bb6b773f?w=800&q=80	Battle royale action with team-based challenges	38450	1680	20	f
138d7afb-8d68-4471-9004-3126b45895c8	Rocket League	Sports	https://images.unsplash.com/photo-1511512578047-dfb367046420?w=800&q=80	Competitive car soccer with ranked progression	28900	1450	18	f
db816905-a387-4e20-9d0f-9d36a5c7e14b	Fortnite	Battle Royale	https://images.unsplash.com/photo-1538481199705-c710c4e965fc?w=800&q=80	Battle royale with building mechanics and daily challenges	89200	1780	35	f
b2bcb1d7-1234-4f2b-9abc-12345678def0	Teamfight Tactics	Auto Battler	https://images.unsplash.com/photo-1511512578047-dfb367046420?w=800&q=80	Strategic auto-battler with ranked progression and TFT Set-specific challenges	42100	1750	26	t
\.


--
-- Data for Name: gaming_events; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.gaming_events (id, partner_id, user_id, game_id, event_type, event_data, points_awarded, transaction_id, external_event_id, status, error_message, retry_count, processed_at, created_at) FROM stdin;
0d08034a-3710-4e34-ad7d-44f11bb579a4	c4c1aacf-e429-4851-afd0-4684fe85219c	7360cfaa-4de7-4a03-96a7-1aaf317e7874	\N	MATCH_WIN	{"score": 1000}	10	0cccfc0d-8bf8-4ca9-8c25-c611761ed5eb	hmac_test_1762676544344	processed	\N	0	2025-11-09 08:22:31.857	2025-11-09 08:22:31.50382
\.


--
-- Data for Name: gg_coin_transactions; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.gg_coin_transactions (id, user_id, amount, reason, source_type, source_id, balance_after, created_at) FROM stdin;
\.


--
-- Data for Name: leaderboard_entries; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.leaderboard_entries (id, user_id, game_id, score, rank, period, updated_at) FROM stdin;
\.


--
-- Data for Name: match_submissions; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.match_submissions (id, user_id, game_id, match_type, notes, screenshot_url, status, points_awarded, reviewed_by, review_notes, submitted_at, reviewed_at, riot_match_id, verified_via_riot, match_data) FROM stdin;
\.


--
-- Data for Name: point_transactions; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.point_transactions (id, user_id, amount, type, source_id, source_type, description, expires_at, created_at, balance_after, is_expired) FROM stdin;
610cf165-ff95-4951-8204-9176ffb62987	9c623996-fd53-4c01-87df-a056e8b9101b	500	EARNED	test-001	MANUAL	Test points	2026-11-09 03:41:10.888297	2025-11-09 03:41:10.888297	500	f
41ce6615-e4c1-429a-bef1-e90b6b87d6fd	922f5e22-cb5e-481d-ab6d-d4e99c131108	500	EARNED	test-002	MANUAL	Test points	\N	2025-11-09 03:47:08.633305	500	f
d1694e4c-d892-439d-9ef8-e6fb79ce51c3	7360cfaa-4de7-4a03-96a7-1aaf317e7874	150	EARNED	sub_test_manual	SUBSCRIPTION_MONTHLY	Basic tier monthly points	\N	2025-11-09 05:55:40.792122	150	f
cbf3e622-76c4-41e4-b99f-6355e953e8ad	7360cfaa-4de7-4a03-96a7-1aaf317e7874	10	MATCH_WIN	51089276-2e45-4f38-8c34-a25339150aa5	gaming_event	Match win - Test Gaming Platform	2026-11-09 08:00:47.304	2025-11-09 08:00:47.136503	160	f
e13a47b7-016a-4d87-a1e0-44b46dc1ba3e	7360cfaa-4de7-4a03-96a7-1aaf317e7874	25	ACHIEVEMENT	ba717f7b-7597-4333-8047-94fa89333be9	gaming_event	First Win	2026-11-09 08:01:23.206	2025-11-09 08:01:23.074687	185	f
b5652a60-8f9a-4a0f-90d1-83e80e925ba3	7360cfaa-4de7-4a03-96a7-1aaf317e7874	100	TOURNAMENT_PLACEMENT	71224539-be07-408a-8a05-3c66ac02416b	gaming_event	Tournament placement #1 - Test Gaming Platform	2026-11-09 08:02:46.967	2025-11-09 08:02:46.83769	285	f
5b562855-0047-4fb1-92cc-53fed1e7a22b	7360cfaa-4de7-4a03-96a7-1aaf317e7874	10	MATCH_WIN	934065c8-9710-40a6-8f0d-373a64667320	gaming_event	Match win - Test Gaming Platform	2026-11-09 08:04:46.948	2025-11-09 08:04:46.772741	295	f
0d0dfa01-af39-4d7b-b1e9-f9cb17374d99	7360cfaa-4de7-4a03-96a7-1aaf317e7874	10	MATCH_WIN	5337eee4-463f-4c6e-aeb3-286cc99c4024	gaming_event	Match win - Test Gaming Platform	2026-11-09 08:05:46.445	2025-11-09 08:05:46.27177	305	f
76408ef0-54c8-47e3-89b4-a9fbba9f7057	7360cfaa-4de7-4a03-96a7-1aaf317e7874	10	MATCH_WIN	1543c398-289c-4199-a104-e7baf2d5dcd3	gaming_event	Match win - Test Gaming Platform	2026-11-09 08:06:19.771	2025-11-09 08:06:19.5915	315	f
0cccfc0d-8bf8-4ca9-8c25-c611761ed5eb	7360cfaa-4de7-4a03-96a7-1aaf317e7874	10	MATCH_WIN	0d08034a-3710-4e34-ad7d-44f11bb579a4	gaming_event	Match win - Test Gaming Platform	2026-11-09 08:22:31.742	2025-11-09 08:22:31.555353	325	f
f903dcd5-8c01-48f4-8cb7-6ce351e762aa	7c229a10-d1bb-453a-9012-bb55ae328e26	-50	REWARD_REDEMPTION	d59ec530-5c78-4deb-a8d4-b96424a240df	reward	Redeemed: Exclusive GG Badge	\N	2025-11-09 09:07:39.253969	450	f
665519e8-ac93-4478-986a-8a4e38428720	9ebc0fdf-647a-466b-830f-68c709920cc6	-50	REWARD_REDEMPTION	d59ec530-5c78-4deb-a8d4-b96424a240df	reward	Redeemed: Exclusive GG Badge	\N	2025-11-09 09:16:08.58678	450	f
39a8c1f5-bca8-4d42-9d9b-98e3c460e6b6	5536a6e1-4df0-4d04-94bc-e51903333e3d	-50	REWARD_REDEMPTION	d59ec530-5c78-4deb-a8d4-b96424a240df	reward	Redeemed: Exclusive GG Badge	\N	2025-11-09 09:25:54.343304	450	f
a7d22165-f6b7-4cbb-87de-34f4a61359bf	7360cfaa-4de7-4a03-96a7-1aaf317e7874	-50	REWARD_REDEMPTION	d59ec530-5c78-4deb-a8d4-b96424a240df	reward	Redeemed: Exclusive GG Badge	\N	2025-11-09 18:03:10.862062	275	f
3df988f9-f652-4bb8-ac6b-8a68de93545a	7360cfaa-4de7-4a03-96a7-1aaf317e7874	-100	REWARD_REDEMPTION	4cb55375-3a1f-4fcb-9d62-5b95ffe82354	reward	Redeemed: Discord Nitro	\N	2025-11-10 03:56:15.977987	175	f
47bf6a96-f52a-4d72-a3f8-ef46f5d49e69	7360cfaa-4de7-4a03-96a7-1aaf317e7874	-150	REWARD_REDEMPTION	63210f27-b8ca-4deb-8305-57263e1945c1	reward	Redeemed: 20% Off Gaming Store	\N	2025-11-10 04:01:32.404959	25	f
\.


--
-- Data for Name: processed_riot_matches; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.processed_riot_matches (id, riot_account_id, match_id, game_ended_at, is_win, points_awarded, transaction_id, processed_at) FROM stdin;
\.


--
-- Data for Name: referrals; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.referrals (id, referrer_id, referred_user_id, status, points_awarded, tier, completion_reason, activated_at, created_at, completed_at) FROM stdin;
\.


--
-- Data for Name: rewards; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.rewards (id, title, description, points_cost, image_url, category, in_stock, real_value, tier, stock, sku, fulfillment_type) FROM stdin;
edf886a8-2e3e-4324-b12b-934598cc9fe9	Razer Gaming Mouse	High-precision wireless gaming mouse	5000	https://images.unsplash.com/photo-1527814050087-3793815479db?w=400&q=80	Gaming Gear	t	50	3	50	RAZER-MOUSE-001	physical
30e2dabf-04c0-447c-af13-04261da47f59	Custom Gaming Chair	Ergonomic gaming chair with lumbar support	15000	https://images.unsplash.com/photo-1598550476439-6847785fcea6?w=400&q=80	Gaming Gear	t	150	3	20	CHAIR-GAMING-001	physical
efb6f3ac-0cfd-4480-ac57-c3234c2079f6	Premium Mechanical Keyboard	RGB mechanical gaming keyboard with custom switches	15000	https://images.unsplash.com/photo-1595225476474-87563907a212?w=400&q=80	Gaming Gear	t	150	4	15	KB-MECH-001	physical
25549ca3-c27c-47fa-8a82-18fd94cb7b1b	VIP Event Ticket	Exclusive access to major gaming event	10000	https://images.unsplash.com/photo-1560253023-3ec5d502959f?w=400&q=80	Experiences	t	100	4	100	EVENT-VIP-001	manual
beda73c5-38cb-477c-9d0e-28407ccb58d6	Gaming Laptop Upgrade Fund	$500 towards a new gaming laptop	50000	https://images.unsplash.com/photo-1593642632823-8f785ba67e45?w=400&q=80	High-Value	t	500	4	5	LAPTOP-FUND-001	manual
d59ec530-5c78-4deb-a8d4-b96424a240df	Exclusive GG Badge	Unlock a premium profile badge	500	https://images.unsplash.com/photo-1614680376573-df3480f0c6ff?w=400&q=80	Digital	t	5	1	\N	\N	automatic
4cb55375-3a1f-4fcb-9d62-5b95ffe82354	Discord Nitro	1 month Discord Nitro subscription	1000	https://images.unsplash.com/photo-1614680376573-df3480f0c6ff?w=400&q=80	Subscriptions	t	10	1	\N	\N	digital_key
63210f27-b8ca-4deb-8305-57263e1945c1	20% Off Gaming Store	Get 20% off your next purchase at partner stores	1500	https://images.unsplash.com/photo-1607604276583-eef5d076aa5f?w=400&q=80	Discounts	t	15	1	\N	\N	code
c83acd8f-b7b4-42f2-a513-d6781e20f92d	Xbox Game Pass	1 month Xbox Game Pass Ultimate	1700	https://images.unsplash.com/photo-1605901309584-818e25960a8f?w=400&q=80	Subscriptions	t	17	2	\N	\N	digital_key
f8cfa9ed-c2fd-49ea-a1c0-53e61a2ad49c	Steam $10 Gift Card	$10 Steam wallet credit	1000	https://images.unsplash.com/photo-1607604276583-eef5d076aa5f?w=400&q=80	Gift Cards	t	10	2	\N	\N	digital_key
fd6fe626-e1e0-42f1-afea-0efead4d9650	Premium Game Skin Pack	Exclusive in-game skins for popular titles	2500	https://images.unsplash.com/photo-1538481199705-c710c4e965fc?w=400&q=80	Digital	t	25	2	\N	\N	digital_key
ca4809c4-9d23-49fc-951b-6cd50665a630	Steam $25 Gift Card	$25 Steam wallet credit	2500	https://images.unsplash.com/photo-1607604276583-eef5d076aa5f?w=400&q=80	Gift Cards	t	25	3	\N	\N	digital_key
8d2c734a-462c-4bb5-8e5f-1fd80e0d85b3	Steam $10 Gift Card	$10 Steam wallet credit	1000	https://images.unsplash.com/photo-1607604276583-eef5d076aa5f?w=400&q=80	Gift Cards	t	10	1	\N	\N	digital_key
04069ec1-077b-456c-a3e6-b7edf6e79104	Steam $25 Gift Card	$25 Steam wallet credit	2500	https://images.unsplash.com/photo-1607604276583-eef5d076aa5f?w=400&q=80	Gift Cards	t	25	2	\N	\N	digital_key
224b9bd6-6f13-4c5b-a781-d7b9b37b3450	Xbox $10 Gift Card	$10 Xbox store credit	1000	https://images.unsplash.com/photo-1605901309584-818e25960a8f?w=400&q=80	Gift Cards	t	10	1	\N	\N	digital_key
1bb760f0-79f6-46d0-9d81-4b5579380754	PlayStation $10 Card	$10 PlayStation store credit	1000	https://images.unsplash.com/photo-1606144042614-b2417e99c4e3?w=400&q=80	Gift Cards	t	10	1	\N	\N	digital_key
93fc981d-1bb1-4b5e-b732-4cc568d7ce30	Amazon $25 Gift Card	$25 Amazon credit	2500	https://images.unsplash.com/photo-1523474253046-8cd2748b5fd2?w=400&q=80	Gift Cards	t	25	2	\N	\N	digital_key
e89aac76-5fc2-4c23-b381-068c2b9ccd5b	Discord Nitro (1 Month)	1 month Discord Nitro subscription	1000	https://images.unsplash.com/photo-1614680376573-df3480f0c6ff?w=400&q=80	Subscriptions	t	10	1	\N	\N	digital_key
7b49d836-3834-4fa2-8351-977cb343a177	$5 Steam Gift Card	Instant delivery digital code for Steam games, DLC, and more. Redeemable worldwide.	6500	/attached_assets/stock_images/steam_gift_card_digi_fc79bd61.jpg	gift_card	t	500	1	\N	\N	manual
df0ce939-e33c-4ae3-a076-330a0897f375	$10 Steam Gift Card	Instant delivery digital code for Steam games, DLC, and more. Redeemable worldwide.	13000	/attached_assets/stock_images/steam_gift_card_digi_fc79bd61.jpg	gift_card	t	1000	1	\N	\N	manual
02ca671d-0a0a-4cbc-a009-83230285e728	$25 Steam Gift Card	Instant delivery digital code for Steam games, DLC, and more. Redeemable worldwide.	33000	/attached_assets/stock_images/steam_gift_card_digi_fc79bd61.jpg	gift_card	t	2500	2	\N	\N	manual
3870e95f-d496-4c15-bc39-64bc2a6acdf9	$50 Steam Gift Card	Instant delivery digital code for Steam games, DLC, and more. Redeemable worldwide.	67000	/attached_assets/stock_images/steam_gift_card_digi_fc79bd61.jpg	gift_card	t	5000	3	\N	\N	manual
90e34e99-ec00-4f7e-be1b-7fb7c01369fd	$10 PlayStation Store Card	Digital code for PlayStation Store. Buy games, add-ons, and subscriptions for PS4/PS5.	13000	/attached_assets/stock_images/playstation_gift_car_b2d04c01.jpg	gift_card	t	1000	1	\N	\N	manual
b3c2fe70-909d-468e-9f57-58fff7fda1e3	$25 PlayStation Store Card	Digital code for PlayStation Store. Buy games, add-ons, and subscriptions for PS4/PS5.	33000	/attached_assets/stock_images/playstation_gift_car_b2d04c01.jpg	gift_card	t	2500	2	\N	\N	manual
f71e8fd8-8fbd-421a-8f98-3e9821508ed5	$50 PlayStation Store Card	Digital code for PlayStation Store. Buy games, add-ons, and subscriptions for PS4/PS5.	67000	/attached_assets/stock_images/playstation_gift_car_b2d04c01.jpg	gift_card	t	5000	3	\N	\N	manual
4b903c4e-4511-401f-84c2-b3a9f9e6a958	$10 Xbox Gift Card	Digital code for Xbox Store. Purchase games, add-ons, and Game Pass on Xbox or Windows.	13000	/attached_assets/stock_images/xbox_gift_card_7cd295ab.jpg	gift_card	t	1000	1	\N	\N	manual
b5e052bb-c47b-4266-a77b-1a19c3f0e51a	$25 Xbox Gift Card	Digital code for Xbox Store. Purchase games, add-ons, and Game Pass on Xbox or Windows.	33000	/attached_assets/stock_images/xbox_gift_card_7cd295ab.jpg	gift_card	t	2500	2	\N	\N	manual
25d2a636-a28d-43c0-98c5-95cb43d5d15e	$50 Xbox Gift Card	Digital code for Xbox Store. Purchase games, add-ons, and Game Pass on Xbox or Windows.	67000	/attached_assets/stock_images/xbox_gift_card_7cd295ab.jpg	gift_card	t	5000	3	\N	\N	manual
8a51dad2-eee0-4787-9eed-2a4ada701a7c	$10 Amazon Gift Card	Digital Amazon gift card. Use for games, gear, accessories, and more. US only.	13000	/attached_assets/stock_images/amazon_gift_card_bb239405.jpg	gift_card	t	1000	1	\N	\N	manual
2e826311-be1b-44fd-b7ae-915657f5e8b1	$25 Amazon Gift Card	Digital Amazon gift card. Use for games, gear, accessories, and more. US only.	33000	/attached_assets/stock_images/amazon_gift_card_bb239405.jpg	gift_card	t	2500	2	\N	\N	manual
9f68e465-8ca7-43cb-bccc-5619ee8cf248	$50 Amazon Gift Card	Digital Amazon gift card. Use for games, gear, accessories, and more. US only.	67000	/attached_assets/stock_images/amazon_gift_card_bb239405.jpg	gift_card	t	5000	3	\N	\N	manual
1daf0c3e-9562-4912-90d6-db8f32c3560a	Xbox Game Pass Core (1 Month)	Online multiplayer + free monthly games for Xbox. Instant code delivery.	15000	/attached_assets/stock_images/xbox_game_pass_subsc_d66f4547.jpg	subscription	t	1100	2	\N	\N	manual
45cafdd0-616f-46c4-8663-6ae8009be3d8	PlayStation Plus Essential (1 Month)	Online multiplayer + monthly free games for PS4/PS5. Instant code delivery.	13000	/attached_assets/stock_images/playstation_plus_sub_24e41cdf.jpg	subscription	t	1000	2	\N	\N	manual
fc42cecc-f01e-4b02-9ddb-300cb0f6dfdc	Discord Nitro (1 Month)	Unlock custom emojis, HD streaming, server boosts, and more. Instant delivery.	13000	/attached_assets/stock_images/discord_nitro_subscr_75a2c7ce.jpg	subscription	t	1000	2	\N	\N	manual
da6c1426-0dcd-4bf4-b847-ae1cdaad7014	Discord Nitro Basic (1 Month)	Custom emojis, HD video, and bigger uploads. Perfect starter tier. Instant delivery.	4000	/attached_assets/stock_images/discord_nitro_subscr_75a2c7ce.jpg	subscription	t	300	1	\N	\N	manual
846e8f81-7b78-49e6-9913-ecc64d759960	1,000 Riot Points	League of Legends currency. Buy champions, skins, and more. NA server.	13000	/attached_assets/stock_images/riot_points_league_o_6a5d0e7e.jpg	in_game_currency	t	1000	1	\N	\N	manual
aef7432f-e6c3-4196-92e0-af75f2a4ad3d	1,350 Valorant Points	Valorant VP currency. Buy agents, skins, and battle pass. NA server.	13000	/attached_assets/stock_images/valorant_points_vp_4422795e.jpg	in_game_currency	t	1000	1	\N	\N	manual
7b76cd94-52df-4820-8393-8353049b8b4d	1,000 V-Bucks	Fortnite currency. Buy skins, emotes, battle pass, and more. Works on all platforms.	11000	/attached_assets/stock_images/fortnite_v-bucks_23422e92.jpg	in_game_currency	t	800	1	\N	\N	manual
\.


--
-- Data for Name: riot_accounts; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.riot_accounts (id, user_id, puuid, game_name, tag_line, region, game, last_synced_at, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: sessions; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.sessions (sid, sess, expire) FROM stdin;
mswGEcSyDkdDKgaxtNf-WLbFwb0U0Iem	{"cookie": {"path": "/", "secure": true, "expires": "2025-11-16T08:52:13.408Z", "httpOnly": true, "originalMaxAge": 604800000}, "test-mock-oidc.replit.app": {"code_verifier": "fdxhRj9wz_brhmQvhUvkRaDun6ou6sA5R2KjabykVoA"}}	2025-11-16 08:52:14
s2PX7GAeS2r-9odv-zfJ7vMRmmo0TGtb	{"cookie": {"path": "/", "secure": true, "expires": "2025-11-19T06:36:25.473Z", "httpOnly": true, "originalMaxAge": 604800000}, "oauth2:id.twitch.tv": {"state": "4LXpliDkMvdKsMGypRRMRBEz"}}	2025-11-19 06:36:26
wHMzsBsnmuoWdtalm9y3jW8UNgqLgxbO	{"cookie": {"path": "/", "secure": true, "expires": "2025-11-16T04:00:32.697Z", "httpOnly": true, "originalMaxAge": 604800000}, "passport": {"user": {"claims": {"aud": "3d3cea8a-85cf-4f88-8c67-be4be4d6239a", "exp": 1762664432, "iat": 1762660832, "iss": "https://test-mock-oidc.replit.app/", "jti": "8d3dd7d38752680210ede1bf65f744d5", "sub": "mvp-test-001", "email": "mvptest@example.com", "username": "MVPTester", "auth_time": 1762660832}, "expires_at": 1762664432, "access_token": "eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6Ijc4MDgyZTlmZjVhOTA1YjIifQ.eyJpc3MiOiJodHRwczovL3Rlc3QtbW9jay1vaWRjLnJlcGxpdC5hcHAvIiwiaWF0IjoxNzYyNjYwODMyLCJleHAiOjE3NjI2NjQ0MzIsInN1YiI6Im12cC10ZXN0LTAwMSIsImVtYWlsIjoibXZwdGVzdEBleGFtcGxlLmNvbSIsInVzZXJuYW1lIjoiTVZQVGVzdGVyIn0.un71yG2pyyxFcuRkFz0xaiIlkP5tkWDiGD8aAhGbNNfjY54bfY0mYasg_4HawhqGeN8qz5qoPqihDl5nzmaxa7rwDN9_54rzRlrUKbsiKBRdaBvQ8Qyy4GZ-AP6SNGRaJvn6w0Dfi2pDi_AHKfkej4BS2sk44p-Y0fhg7-DvtFi0Xx_6A1oq8DMMARix8JsBABdEZbYWigMLVLMbfDVWzsOJVJ764ognDyScwgDQnF0fn-84sdawVXrnu1nFCrOxSbOZwYtp0oj052rOMfS7ZnJFv3D7TKuQxtshJNoeFN63hxVJFow6j81vqNvfcQZAWFFc0hWlglE1Ip4sB1RVaQ", "refresh_token": "eyJzdWIiOiJtdnAtdGVzdC0wMDEiLCJlbWFpbCI6Im12cHRlc3RAZXhhbXBsZS5jb20iLCJ1c2VybmFtZSI6Ik1WUFRlc3RlciJ9"}}}	2025-11-16 04:00:45
7bX50t100D1truZYqXXTp8FaDCrRYXUt	{"cookie": {"path": "/", "secure": true, "expires": "2025-11-16T04:04:44.616Z", "httpOnly": true, "originalMaxAge": 604800000}, "passport": {"user": {"claims": {"aud": "3d3cea8a-85cf-4f88-8c67-be4be4d6239a", "exp": 1762664682, "iat": 1762661082, "iss": "https://test-mock-oidc.replit.app/", "jti": "bc7836951a4b28f87a6a9b851d052aa3", "sub": "final-mvp-sub", "email": "final-mvp-test@example.com", "username": "FinalMVPUser", "auth_time": 1762661082}, "expires_at": 1762664682, "access_token": "eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6Ijc4MDgyZTlmZjVhOTA1YjIifQ.eyJpc3MiOiJodHRwczovL3Rlc3QtbW9jay1vaWRjLnJlcGxpdC5hcHAvIiwiaWF0IjoxNzYyNjYxMDgyLCJleHAiOjE3NjI2NjQ2ODIsInN1YiI6ImZpbmFsLW12cC1zdWIiLCJlbWFpbCI6ImZpbmFsLW12cC10ZXN0QGV4YW1wbGUuY29tIiwidXNlcm5hbWUiOiJGaW5hbE1WUFVzZXIifQ.Od-Y5F6T7ZP6ViWlUxSsRawqdMlRuwfuWgiQ0LWvHo-1wNPACFX1P2fh3KEvAJMOiZKvDY916YiPHBRam16EMeeYTSt3qBeMnluMJeG1MdtOmGySdaC4Pvcf2dv7Pmwg1WvXmpc41iwrxGyyCZYxfue4isd6CJ3DoN6NFrEBqvundUZVaWNRHbaP3b1keU4WwiB1e6fRz4mwb1iN126ABO6Wp7M3MxpXvjCyd11U1Kva1wqWVPbdQGA4L-YIZ537Ggj5ZZrS32sAVWpxvS-_eJE4AVZx1GRVli2r38GDYZ7xXYWokYmEwympyUnvG_mkKl1fDf0Ayb5pd4G7uDVdEQ", "refresh_token": "eyJzdWIiOiJmaW5hbC1tdnAtc3ViIiwiZW1haWwiOiJmaW5hbC1tdnAtdGVzdEBleGFtcGxlLmNvbSIsInVzZXJuYW1lIjoiRmluYWxNVlBVc2VyIn0"}}}	2025-11-16 04:04:58
6kkP61LWm0cM5x8hf6J785S7k1gTXvEo	{"cookie": {"path": "/", "secure": true, "expires": "2025-11-16T04:06:50.105Z", "httpOnly": true, "originalMaxAge": 604800000}, "passport": {"user": {"claims": {"aud": "3d3cea8a-85cf-4f88-8c67-be4be4d6239a", "exp": 1762664809, "iat": 1762661209, "iss": "https://test-mock-oidc.replit.app/", "jti": "ea3e90f32c4be79a177258650e03e76e", "sub": "mvp-final-001", "email": "mvp-final@example.com", "auth_time": 1762661209, "last_name": "Final", "first_name": "MVP"}, "expires_at": 1762664809, "access_token": "eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6Ijc4MDgyZTlmZjVhOTA1YjIifQ.eyJpc3MiOiJodHRwczovL3Rlc3QtbW9jay1vaWRjLnJlcGxpdC5hcHAvIiwiaWF0IjoxNzYyNjYxMjA5LCJleHAiOjE3NjI2NjQ4MDksInN1YiI6Im12cC1maW5hbC0wMDEiLCJlbWFpbCI6Im12cC1maW5hbEBleGFtcGxlLmNvbSIsImZpcnN0X25hbWUiOiJNVlAiLCJsYXN0X25hbWUiOiJGaW5hbCJ9.iqKrhU3rS6m9VNwuouF5Z08nUXPNq6eh8oKCAqDHvqs0_I3A9OlC0YL24-OFznFudle9jItXVHyJ4poLNZR-_tCHqRBdiowwy9nDY62WmPxR652aOT4umZl6XfNo5juyWwGo7pRc_lgZYNu_zvVzSPiGhICvlTeE7Nqy2nI9TZAz1690kmldIO53dwzTkMn5kgwazD4f_9FTHLDKvzpdkoNyg7YoQ9Qzc_41oK3AL9prBJRdTGjDrC-eutLZGsA6lUkB-Rlfvtm7akGv1ByrShEfUUqjdVZgXitVqOBJOSD0nIfp2_OibIMldOKAOz2fg1low8VBvvKr5_ZNvBomqQ", "refresh_token": "eyJzdWIiOiJtdnAtZmluYWwtMDAxIiwiZW1haWwiOiJtdnAtZmluYWxAZXhhbXBsZS5jb20iLCJmaXJzdF9uYW1lIjoiTVZQIiwibGFzdF9uYW1lIjoiRmluYWwifQ"}}}	2025-11-16 04:07:44
HYTRVlqRXTlITqBS59BzAxi2t5NpSw7G	{"cookie": {"path": "/", "secure": true, "expires": "2025-11-16T02:28:11.119Z", "httpOnly": true, "originalMaxAge": 604800000}, "replit.com": {"code_verifier": "rpVsasB-21mcAgfVAoy9WJtjJEah0tGWWBJp5LWdESM"}}	2025-11-16 03:40:53
eqncxrNcV3oPVFTZvoNaYeocOZFDbUPU	{"cookie": {"path": "/", "secure": true, "expires": "2025-11-16T03:47:31.252Z", "httpOnly": true, "originalMaxAge": 604800000}, "test-mock-oidc.replit.app": {"code_verifier": "xFrIrMCVm9Urt4r27vki0fA4FMeNFM3huDxvgTlGsP4"}}	2025-11-16 03:47:32
kyrYUluGxgGprfgNVYs9BPsg8st3Brw_	{"cookie": {"path": "/", "secure": true, "expires": "2025-11-16T03:56:25.212Z", "httpOnly": true, "originalMaxAge": 604800000}, "passport": {"user": {"claims": {"aud": "3d3cea8a-85cf-4f88-8c67-be4be4d6239a", "exp": 1762664184, "iat": 1762660584, "iss": "https://test-mock-oidc.replit.app/", "jti": "e4835971c13f5613a9a11c05fbe82941", "sub": "final-test-sub-001", "email": "authfinal1@example.com", "username": "FinalTestUser", "auth_time": 1762660584}, "expires_at": 1762664184, "access_token": "eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6Ijc4MDgyZTlmZjVhOTA1YjIifQ.eyJpc3MiOiJodHRwczovL3Rlc3QtbW9jay1vaWRjLnJlcGxpdC5hcHAvIiwiaWF0IjoxNzYyNjYwNTg0LCJleHAiOjE3NjI2NjQxODQsInN1YiI6ImZpbmFsLXRlc3Qtc3ViLTAwMSIsImVtYWlsIjoiYXV0aGZpbmFsMUBleGFtcGxlLmNvbSIsInVzZXJuYW1lIjoiRmluYWxUZXN0VXNlciJ9.krFaJlGLMAkMCKI-pebpd-qtOvtp9Lk6BQEzjDvLz7543wxxzGGAtpXl1mx9Muv9YSlJS6tQtrjuqB-b7ugj-5_8Y9iT87odv6KCoqQ8UFtDmElEPf0HbEowCcFP1oCQ7_3crvy-A_zrhCzBXWNt3JzUWGBJMYspA39mfA14r28uwgNz3bNG2JU3PxAxia_QQFNbPur7OTtneerMThp8YM3hr60MXyL9-zgzn2Zs_2sd-MUC9GYnoprwFzGPOAsijtPhQP4P9c8qgKPTBksVkD7yQHWSUAy9Yj7DbZt8Aubi_2r81N1FvbZc2OOY2FvoEPHv2x6043AO9XMInpZWGA", "refresh_token": "eyJzdWIiOiJmaW5hbC10ZXN0LXN1Yi0wMDEiLCJlbWFpbCI6ImF1dGhmaW5hbDFAZXhhbXBsZS5jb20iLCJ1c2VybmFtZSI6IkZpbmFsVGVzdFVzZXIifQ"}}}	2025-11-16 03:57:56
gV8vDWpJQ3jz-11WOZNL-PW1JxWFJ3xv	{"cookie": {"path": "/", "secure": true, "expires": "2025-11-19T06:37:36.840Z", "httpOnly": true, "originalMaxAge": 604800000}, "oauth2:id.twitch.tv": {"state": "JSrVO1WMAYg6CsFNBKCxbaDK"}}	2025-11-19 06:37:37
oi1DjbmSsVuKs9vhhBzj95q9KySw1jw_	{"cookie": {"path": "/", "secure": true, "expires": "2025-11-16T12:42:41.583Z", "httpOnly": true, "originalMaxAge": 604799999}, "passport": {"user": {"claims": {"aud": "3d3cea8a-85cf-4f88-8c67-be4be4d6239a", "exp": 1762695761, "iat": 1762692161, "iss": "https://test-mock-oidc.replit.app/", "jti": "a8a219347dc5c8154e495501e97fbc5d", "sub": "IY3R7b", "email": "IY3R7b@example.com", "auth_time": 1762692161, "last_name": "Doe", "first_name": "John"}, "expires_at": 1762695761, "access_token": "eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6Ijc4MDgyZTlmZjVhOTA1YjIifQ.eyJpc3MiOiJodHRwczovL3Rlc3QtbW9jay1vaWRjLnJlcGxpdC5hcHAvIiwiaWF0IjoxNzYyNjkyMTYxLCJleHAiOjE3NjI2OTU3NjEsInN1YiI6IklZM1I3YiIsImVtYWlsIjoiSVkzUjdiQGV4YW1wbGUuY29tIiwiZmlyc3RfbmFtZSI6IkpvaG4iLCJsYXN0X25hbWUiOiJEb2UifQ.cuyF9lX9rBDym91fxuIbuECgfLllE6CkvCbnaqFHFeGFehn1X3iZrGkNRGYvHwt5WF6R-j5JtLTFISkEFquxs3Js0yuXLbZ-xPubyQkSU9AN_-_5snue3YFgTqTATAwNO8xUBjEVZ1h2zXqDZKo2mkrd-ZCILjtadVsEHalZVQVf0dJoMVl1K67mMVLXwchRHHfXeFEaGGLzo15c4b9Nolq_GsBTf9e5T6yodWdWw73p8LXLJ5DBwlfeMXtoDgUJQnOEXJ_E3u9VwElndwbnQBZE67ZIbyWDOckn6vPSVTBdcvyLFrWSASMTe6j1_PJvJXR1DyWzSYfQvjCNkWfMZQ", "refresh_token": "eyJzdWIiOiJJWTNSN2IiLCJlbWFpbCI6IklZM1I3YkBleGFtcGxlLmNvbSIsImZpcnN0X25hbWUiOiJKb2huIiwibGFzdF9uYW1lIjoiRG9lIn0"}}}	2025-11-16 12:43:09
o9xkdrrnv0gFRullLTN4a2w2FYmRziWc	{"cookie": {"path": "/", "secure": true, "expires": "2025-11-16T09:12:39.111Z", "httpOnly": true, "originalMaxAge": 604800000}, "passport": {"user": {"claims": {"aud": "3d3cea8a-85cf-4f88-8c67-be4be4d6239a", "exp": 1762683158, "iat": 1762679558, "iss": "https://test-mock-oidc.replit.app/", "jti": "dbf6e368b7e5d5a4e533d5cce10969c3", "sub": "test-ui-fix-Zttz-d", "email": "uifix@example.com", "auth_time": 1762679558, "last_name": "Test", "first_name": "UI"}, "expires_at": 1762683158, "access_token": "eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6Ijc4MDgyZTlmZjVhOTA1YjIifQ.eyJpc3MiOiJodHRwczovL3Rlc3QtbW9jay1vaWRjLnJlcGxpdC5hcHAvIiwiaWF0IjoxNzYyNjc5NTU4LCJleHAiOjE3NjI2ODMxNTgsInN1YiI6InRlc3QtdWktZml4LVp0dHotZCIsImVtYWlsIjoidWlmaXhAZXhhbXBsZS5jb20iLCJmaXJzdF9uYW1lIjoiVUkiLCJsYXN0X25hbWUiOiJUZXN0In0.dLOYM4OHutp8p7rPmHrBZUTuTJavcd4SKC3KCmt66d1Lp8YytSxBWC1_3P3SFpSZE7xGCpfTEuvT2OYE_mWbqikjR5_b7iFaAWE49j-FWILFzVllMJc_sCQ6pa_2q3realmsgIFiPPT6dQTRBFh40LNJviTifpu2vNJsFWYUb9T8jOqAXTDDiExIe54A_Qygjx0ehUOgljfjJ8gWHcPlMdt_so1v6-RWsTNfo6NwydVMK9kk7n18W4aFa3T0ozZd8q_W5dtbM_KlUGwM2z1il9AEB74PEv4sCIqml1RztTLwnmQ2lLjLEkGhpcKJa8727c1t-UySIhRBRXBxFq5smg", "refresh_token": "eyJzdWIiOiJ0ZXN0LXVpLWZpeC1adHR6LWQiLCJlbWFpbCI6InVpZml4QGV4YW1wbGUuY29tIiwiZmlyc3RfbmFtZSI6IlVJIiwibGFzdF9uYW1lIjoiVGVzdCJ9"}}}	2025-11-16 09:13:37
WrrNMRzRuCyxWQyamZYEjpz6X0Gv7HYy	{"cookie": {"path": "/", "secure": true, "expires": "2025-11-18T22:30:10.958Z", "httpOnly": true, "originalMaxAge": 604800000}, "passport": {"user": {"email": "quindaojayson50@yahoo.com", "oidcSub": "discord:218205738751885313", "provider": "discord", "providerId": "218205738751885313", "displayName": "jrip0441", "profileImage": "https://cdn.discordapp.com/avatars/218205738751885313/1c27e2ca180e5531dfd18216faed294c.png"}}}	2025-11-18 22:30:15
RoPWIVZW90xID_HynNG5J8iEku7lcnrH	{"cookie": {"path": "/", "secure": true, "expires": "2025-11-19T06:40:14.478Z", "httpOnly": true, "originalMaxAge": 604800000}, "passport": {"user": {"claims": {"aud": "3d3cea8a-85cf-4f88-8c67-be4be4d6239a", "exp": 1762833902, "iat": 1762830302, "iss": "https://replit.com/oidc", "sub": "20695111", "email": "jaysonquindao1@gmail.com", "at_hash": "puZi2ZxAMLtKrnO76gXxog", "username": "JaysonQuindao", "auth_time": 1762664486, "last_name": "Quindao", "first_name": "Jayson"}, "expires_at": 1762833902, "access_token": "_aE1qwQ88xUAQxAdtedtzAs4XFnUdvAx-I-ZoxLtJy4", "refresh_token": "kZZd7et8GSXWmOj7gDv75SlbsumRk8PzaQ0zUvNpZkm"}}, "twitchState": "8dab127e488afe263501c78dd85b9bc92dcbf96ca0657031c57f8b734faa07fb", "oauth2:id.twitch.tv": {"state": "0LQ3cdw3wE98wrd7evPjrucO"}, "oauth2:accounts.google.com": {"state": "FJAjzYmVLlfboztH7spyO02o"}}	2025-11-19 06:47:07
Q2kNNWiEtFbvMpxT_uHhAz_y9ZW_IwLI	{"cookie": {"path": "/", "secure": true, "expires": "2025-11-16T09:15:18.295Z", "httpOnly": true, "originalMaxAge": 604800000}, "passport": {"user": {"claims": {"aud": "3d3cea8a-85cf-4f88-8c67-be4be4d6239a", "exp": 1762683318, "iat": 1762679718, "iss": "https://test-mock-oidc.replit.app/", "jti": "67cd5af6c9f92ac6ac023e0db6ecc7c1", "sub": "final-test-HHMK_m", "email": "finaltest@example.com", "auth_time": 1762679718, "last_name": "Tester", "first_name": "Final"}, "expires_at": 1762683318, "access_token": "eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6Ijc4MDgyZTlmZjVhOTA1YjIifQ.eyJpc3MiOiJodHRwczovL3Rlc3QtbW9jay1vaWRjLnJlcGxpdC5hcHAvIiwiaWF0IjoxNzYyNjc5NzE4LCJleHAiOjE3NjI2ODMzMTgsInN1YiI6ImZpbmFsLXRlc3QtSEhNS19tIiwiZW1haWwiOiJmaW5hbHRlc3RAZXhhbXBsZS5jb20iLCJmaXJzdF9uYW1lIjoiRmluYWwiLCJsYXN0X25hbWUiOiJUZXN0ZXIifQ.FY_w6ee4P05cYMyHI9CgHOICcaCnA62I8HjCB4XQ8KSJWaqzB3o8yceJVZKlDZT2CJn1JFgHvfAnteqHGKJNA-45ESqbiaw8SNlpfmc2I0fu_WzWZUcG7NmtVzXeAEJhwtmifJZdjtEyREadLmRyBOG_d2AlhuaW5dtw2zGWEvprqU9Tu7qah2NTaeNkK8hqeZzHC-k_6yi_mtmGdTB3F2PRFCwOrIbYGosHsmxUk0dJQDzdEBuGGaHvNJrn6jlU8dK5PeZrdeMmU7rB7ugawN3Wv22vi3JdEcDjjo68FNXZm5JNaEZo7Jn-MfbehD4fYdr17ElECZwaO5fwPgEE2g", "refresh_token": "eyJzdWIiOiJmaW5hbC10ZXN0LUhITUtfbSIsImVtYWlsIjoiZmluYWx0ZXN0QGV4YW1wbGUuY29tIiwiZmlyc3RfbmFtZSI6IkZpbmFsIiwibGFzdF9uYW1lIjoiVGVzdGVyIn0"}}}	2025-11-16 09:16:50
nEMDHe82hrApjh5CnSfb_9bdd9TiOLg0	{"cookie": {"path": "/", "secure": true, "expires": "2025-11-16T06:01:19.399Z", "httpOnly": true, "originalMaxAge": 604800000}, "passport": {"user": {"claims": {"aud": "3d3cea8a-85cf-4f88-8c67-be4be4d6239a", "exp": 1762671679, "iat": 1762668079, "iss": "https://test-mock-oidc.replit.app/", "jti": "671117fbaf37f7bf4cc7f861201f65a9", "sub": "20695111", "email": "jaysonquindao1@gmail.com", "auth_time": 1762668078, "last_name": "Quindao", "first_name": "Jayson"}, "expires_at": 1762671679, "access_token": "eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6Ijc4MDgyZTlmZjVhOTA1YjIifQ.eyJpc3MiOiJodHRwczovL3Rlc3QtbW9jay1vaWRjLnJlcGxpdC5hcHAvIiwiaWF0IjoxNzYyNjY4MDc5LCJleHAiOjE3NjI2NzE2NzksInN1YiI6IjIwNjk1MTExIiwiZW1haWwiOiJqYXlzb25xdWluZGFvMUBnbWFpbC5jb20iLCJmaXJzdF9uYW1lIjoiSmF5c29uIiwibGFzdF9uYW1lIjoiUXVpbmRhbyJ9.vwwgRFtdoK2CodvN33QouSgrEMmx7XAS1mCPQfTyFQJQggjwwqMMDWklH-z1Wwohpkx-m_eFdBWxKO8fybVSreuYe1CdoaSndAGgSLWrAHalnuiJx2W3TjHyeLp6OZUSWoqMDbUuf5YrXMK5N7GVl8J7W5LgRSIuEFEI-n1lP6ubebsSrwme1vJ63HuklH6csPrMFcl1woDLcacS6of9iC4ws36ApunvS2LDz86lfEkZdOmAcL9Ufl75TAQhbk-_Coi4c4Dy3X5OpIsJ8vgEkJbCFnNHLpbArZKwR6JR5dN8evxmVOD8Y2mtCS9AbeuO6YDlgNEcIS0Lq70GoK777g", "refresh_token": "eyJzdWIiOiIyMDY5NTExMSIsImVtYWlsIjoiamF5c29ucXVpbmRhbzFAZ21haWwuY29tIiwiZmlyc3RfbmFtZSI6IkpheXNvbiIsImxhc3RfbmFtZSI6IlF1aW5kYW8ifQ"}}}	2025-11-16 06:01:44
Wdo9QKc5rVERMxjMJXLWkFb2BwWgNYy3	{"cookie": {"path": "/", "secure": true, "expires": "2025-11-16T04:59:13.272Z", "httpOnly": true, "originalMaxAge": 604800000}, "passport": {"user": {"claims": {"aud": "3d3cea8a-85cf-4f88-8c67-be4be4d6239a", "exp": 1762667952, "iat": 1762664352, "iss": "https://replit.com/oidc", "sub": "20695111", "email": "jaysonquindao1@gmail.com", "at_hash": "sNdD6WlTyAXehE-t6zk6Nw", "username": "JaysonQuindao", "auth_time": 1762664352, "last_name": "Quindao", "first_name": "Jayson"}, "expires_at": 1762667952, "access_token": "Y5kv-KPQjKE_x_ontdoyR1V83VgOYRy738UU1JP8ouM", "refresh_token": "ArykF3ZW1Eej0j0wTC0nkZhNm9Bwd4NrnUPHskJmWLQ"}}}	2025-11-16 04:59:25
VrPE2tReFq4NSwnzhcD6TmBLIFSh654P	{"cookie": {"path": "/", "secure": true, "expires": "2025-11-16T08:47:56.150Z", "httpOnly": true, "originalMaxAge": 604800000}, "passport": {"user": {"claims": {"aud": "3d3cea8a-85cf-4f88-8c67-be4be4d6239a", "exp": 1762681675, "iat": 1762678075, "iss": "https://test-mock-oidc.replit.app/", "jti": "463809b3f8b001d4a48858ac3f40d6a3", "sub": "DLZfLy", "email": "DLZfLy@example.com", "auth_time": 1762678075, "last_name": "Doe", "first_name": "John"}, "expires_at": 1762681675, "access_token": "eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6Ijc4MDgyZTlmZjVhOTA1YjIifQ.eyJpc3MiOiJodHRwczovL3Rlc3QtbW9jay1vaWRjLnJlcGxpdC5hcHAvIiwiaWF0IjoxNzYyNjc4MDc1LCJleHAiOjE3NjI2ODE2NzUsInN1YiI6IkRMWmZMeSIsImVtYWlsIjoiRExaZkx5QGV4YW1wbGUuY29tIiwiZmlyc3RfbmFtZSI6IkpvaG4iLCJsYXN0X25hbWUiOiJEb2UifQ.uwEBrqNMaZ9TZKNlA5drlNoD3V5lKSBW3AsyLNDI9--Fu5fM2hAqSfhAEFzv48FRmWDCrVPHB7qh4wS0un_NhvK7jEdpkXa0QX2ifKRGgUr3yva2V4xyzvcFfk4uroj7Dr_-tKXCzxvirH6bIaKLpFFqYn1LcJK77TmAgnLyMAog5X2EMypINfs6A475D_MuvCG4WW-ZA3BZj2xk_jGWPWYe9RoxkGBnd-YxezCr_vZ8GnFpJzQTmfwqbk_Y6x9E4ekijSy3j5rbHF2S1QC-55cqXYf7F4QMfLEOCI0KeYcX8fOG6EuCiA66X-umxSVK1tK10JjXttLGeR9A6Gf4Cw", "refresh_token": "eyJzdWIiOiJETFpmTHkiLCJlbWFpbCI6IkRMWmZMeUBleGFtcGxlLmNvbSIsImZpcnN0X25hbWUiOiJKb2huIiwibGFzdF9uYW1lIjoiRG9lIn0"}}}	2025-11-16 08:48:22
ZGas_BhAqcegUihQ2Hir2kLdeNpSGpsD	{"cookie": {"path": "/", "secure": true, "expires": "2025-11-17T14:18:42.159Z", "httpOnly": true, "originalMaxAge": 604800000}, "passport": {"user": {"claims": {"aud": "3d3cea8a-85cf-4f88-8c67-be4be4d6239a", "exp": 1762787919, "iat": 1762784319, "iss": "https://replit.com/oidc", "sub": "20695111", "email": "jaysonquindao1@gmail.com", "at_hash": "9hMx2eHZw6OcJj_swveArw", "username": "JaysonQuindao", "auth_time": 1762681754, "last_name": "Quindao", "first_name": "Jayson"}, "expires_at": 1762787919, "access_token": "WVM89ckvaZNF7Q6KlZPZ0okYZ-lBVaBxLfOP_a8JRCn", "refresh_token": "fHasipX8dWIhkVkD60CEWBeJm1ACMG3voSH8V3grG0M"}}}	2025-11-19 05:35:17
m47Nx-6oqNXOSg-TALXT1Fy5FeHqcrlW	{"cookie": {"path": "/", "secure": true, "expires": "2025-11-16T08:59:45.201Z", "httpOnly": true, "originalMaxAge": 604800000}, "passport": {"user": {"claims": {"aud": "3d3cea8a-85cf-4f88-8c67-be4be4d6239a", "exp": 1762682385, "iat": 1762678785, "iss": "https://test-mock-oidc.replit.app/", "jti": "136601ce11f787350c221cb0e362d983", "sub": "test-claim-user-CswhD5", "email": "claimtest@example.com", "auth_time": 1762678784, "last_name": "Tester", "first_name": "Claim"}, "expires_at": 1762682385, "access_token": "eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6Ijc4MDgyZTlmZjVhOTA1YjIifQ.eyJpc3MiOiJodHRwczovL3Rlc3QtbW9jay1vaWRjLnJlcGxpdC5hcHAvIiwiaWF0IjoxNzYyNjc4Nzg1LCJleHAiOjE3NjI2ODIzODUsInN1YiI6InRlc3QtY2xhaW0tdXNlci1Dc3doRDUiLCJlbWFpbCI6ImNsYWltdGVzdEBleGFtcGxlLmNvbSIsImZpcnN0X25hbWUiOiJDbGFpbSIsImxhc3RfbmFtZSI6IlRlc3RlciJ9.GfaBsVf_xzWzoHG6piYp_ZFme5dt54bNca5eb8QBdcYs68-Z2xUxugymXZBq0Oob7AzS0P4yXk_6aFr3Y8bKTHUmeu5rfd7LEMOOB9_DQwJxI8sJU4fZBvgW8Hbgx3N6nATFgk-iiQW79qyJMzhzpYZ1w0AmghYu-fwx0DK5YyoIsNpNYP_FWrKHmSY_w_QKb57xblAehPzAJFdpd7UhqNM-KNWHdoqsaf_DvUA2yg9eHmvmk7CrqHghIeY5n3_oNTwBhPFNNQpaaGsiF9Pgkbk94Pzr9b1eva8AU11vTIf531o90nhld-0o5YEZ2Bwn_oihmJEYq2SQnAFiBnDgmw", "refresh_token": "eyJzdWIiOiJ0ZXN0LWNsYWltLXVzZXItQ3N3aEQ1IiwiZW1haWwiOiJjbGFpbXRlc3RAZXhhbXBsZS5jb20iLCJmaXJzdF9uYW1lIjoiQ2xhaW0iLCJsYXN0X25hbWUiOiJUZXN0ZXIifQ"}}}	2025-11-16 09:10:13
C7WUtkt4K6-1c1GJWN1OxsWm2DYAwNLE	{"cookie": {"path": "/", "secure": true, "expires": "2025-11-19T00:30:09.908Z", "httpOnly": true, "originalMaxAge": 604800000}, "oauth2:id.twitch.tv": {"state": "bJq0PdOhude41DJZHD9YazHK"}, "oauth2:accounts.google.com": {"state": "DRPEcyDyN1dnlIFnl4eDbQEW"}}	2025-11-19 00:48:50
c4o6D1Wal0l5Z2ii5qeVZJ-DYnGJb4t_	{"cookie": {"path": "/", "secure": true, "expires": "2025-11-16T09:19:35.677Z", "httpOnly": true, "originalMaxAge": 604799999}, "passport": {"user": {"claims": {"aud": "3d3cea8a-85cf-4f88-8c67-be4be4d6239a", "exp": 1762683575, "iat": 1762679975, "iss": "https://test-mock-oidc.replit.app/", "jti": "02d8b9c3276d76d66aef7bd6e034c79e", "sub": "secure-test-_KPMgI", "email": "secure@example.com", "auth_time": 1762679975, "last_name": "Test", "first_name": "Secure"}, "expires_at": 1762683575, "access_token": "eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6Ijc4MDgyZTlmZjVhOTA1YjIifQ.eyJpc3MiOiJodHRwczovL3Rlc3QtbW9jay1vaWRjLnJlcGxpdC5hcHAvIiwiaWF0IjoxNzYyNjc5OTc1LCJleHAiOjE3NjI2ODM1NzUsInN1YiI6InNlY3VyZS10ZXN0LV9LUE1nSSIsImVtYWlsIjoic2VjdXJlQGV4YW1wbGUuY29tIiwiZmlyc3RfbmFtZSI6IlNlY3VyZSIsImxhc3RfbmFtZSI6IlRlc3QifQ.ddun6yCU-YKCj7WwyaAPK2gZ9jn2yUwFGfrStakDqsdkhsNF54cM3dAK2BLbvLnc9fc93UMRogSrk_AcZxmxAM9KXr9CeGJh2LHKe51yrhudhJkV0ZJQ9K-mlSlfZSMpJdnIntF_VsFl7iUq07_OuCWwn_L3e0qL8ZCEckApU9nIQfuyDhJ4Mk15qInvkRq7dR1vNIwz4sZByrYdqssRGTXl9Fr3N6mMkQmkszaA3X11zEWBXEKIrjT9wtpTy4LToHhQW42ijFvpFwP917rzuKYNf_y1ICRgW5qDdwMGcTACVmsrjEIuM_I0zWDy2YcSIpzkrn6z8QiVW04jcYqS0w", "refresh_token": "eyJzdWIiOiJzZWN1cmUtdGVzdC1fS1BNZ0kiLCJlbWFpbCI6InNlY3VyZUBleGFtcGxlLmNvbSIsImZpcnN0X25hbWUiOiJTZWN1cmUiLCJsYXN0X25hbWUiOiJUZXN0In0"}}}	2025-11-16 09:20:56
RYuHnZQ2HNat1ssO66Qkj96-6pYBYjBL	{"cookie": {"path": "/", "secure": true, "expires": "2025-11-16T03:53:13.057Z", "httpOnly": true, "originalMaxAge": 604800000}, "passport": {"user": {"claims": {"aud": "3d3cea8a-85cf-4f88-8c67-be4be4d6239a", "exp": 1762663992, "iat": 1762660392, "iss": "https://test-mock-oidc.replit.app/", "jti": "62eca3deac493a2b991309d113375337", "sub": "auth-test-sub-001", "email": "testauth1@example.com", "auth_time": 1762660392, "last_name": "TestUser1", "first_name": "Auth"}, "expires_at": 1762663992, "access_token": "eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6Ijc4MDgyZTlmZjVhOTA1YjIifQ.eyJpc3MiOiJodHRwczovL3Rlc3QtbW9jay1vaWRjLnJlcGxpdC5hcHAvIiwiaWF0IjoxNzYyNjYwMzkyLCJleHAiOjE3NjI2NjM5OTIsInN1YiI6ImF1dGgtdGVzdC1zdWItMDAxIiwiZW1haWwiOiJ0ZXN0YXV0aDFAZXhhbXBsZS5jb20iLCJmaXJzdF9uYW1lIjoiQXV0aCIsImxhc3RfbmFtZSI6IlRlc3RVc2VyMSJ9.b8PmSK5ln8HL2duoaGVtAO6iCNjfSfURUInrOsLIORYVxFGc1hFMX_hIxj26a_NUpBTf6vaCg5wRnVLJDS08r4y0gS6m8y7xFQVQYt1O7Pe3_43NSiWMmgw6PxJyb03XcwmZGIjD2dfUQdQJG-xaW8szUfyx2lzzyXd6qYDh7qLD_6oVhQnzoDBz5EqAUqsNQsHUw2qFcMNLTaxlY1EX-WU18yecUyRaQFMOwzU_Q-ZWGvGgJpB5s6qnjnSqm55Is7Se4j27BBodMIU5ibHeFahfyGzqalo_KRFVkj3MAUiFnr5PZ-zva82X4hC49-JH1Jn8q5EitMFJnEF_eoTt-A", "refresh_token": "eyJzdWIiOiJhdXRoLXRlc3Qtc3ViLTAwMSIsImVtYWlsIjoidGVzdGF1dGgxQGV4YW1wbGUuY29tIiwiZmlyc3RfbmFtZSI6IkF1dGgiLCJsYXN0X25hbWUiOiJUZXN0VXNlcjEifQ"}}}	2025-11-16 03:53:26
mo8rnR5bf_kJLL2t6vprksLa2JDDKSo0	{"cookie": {"path": "/", "secure": true, "expires": "2025-11-16T09:22:05.024Z", "httpOnly": true, "originalMaxAge": 604800000}, "passport": {"user": {"claims": {"aud": "3d3cea8a-85cf-4f88-8c67-be4be4d6239a", "exp": 1762683724, "iat": 1762680124, "iss": "https://test-mock-oidc.replit.app/", "jti": "90e95c5eccc2995c8d5736a35315705c", "sub": "secure-v2-hEtyrl", "email": "securev2@example.com", "auth_time": 1762680124, "last_name": "V2", "first_name": "Secure"}, "expires_at": 1762683724, "access_token": "eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6Ijc4MDgyZTlmZjVhOTA1YjIifQ.eyJpc3MiOiJodHRwczovL3Rlc3QtbW9jay1vaWRjLnJlcGxpdC5hcHAvIiwiaWF0IjoxNzYyNjgwMTI0LCJleHAiOjE3NjI2ODM3MjQsInN1YiI6InNlY3VyZS12Mi1oRXR5cmwiLCJlbWFpbCI6InNlY3VyZXYyQGV4YW1wbGUuY29tIiwiZmlyc3RfbmFtZSI6IlNlY3VyZSIsImxhc3RfbmFtZSI6IlYyIn0.mbZ2_pzrMZimN3pPh1AkbAS8fV9UaVlqzvIqoHaSl62eIvby7m4fE0L1ve8f4WRo4Kx_gn2-XueXgf1iBNr4BAznRRYfB1_NKbmXc5H_vXFSMXbpPOc2GFL1Kt__lTGjCCwO77u-VKyGTERZXjYXOXChdadrPc61DkBX7CZdEgXFaDiXQo9H8cHGQXMH40-ONy-FEXx-Cf_l4gebG7V_vk84wuatVN9nfcEVpFDI1oVLG3yT5RvLuJrLDrDZlLySBVA-e3rDEL9ojywzbXT4WrEXFhJTwbs_XFGYxxjvufpP1jG7gNtchqy0MoclqNbBPVk5heEueqKr2u10mHvI0A", "refresh_token": "eyJzdWIiOiJzZWN1cmUtdjItaEV0eXJsIiwiZW1haWwiOiJzZWN1cmV2MkBleGFtcGxlLmNvbSIsImZpcnN0X25hbWUiOiJTZWN1cmUiLCJsYXN0X25hbWUiOiJWMiJ9"}}}	2025-11-16 09:26:18
\.


--
-- Data for Name: subscription_events; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.subscription_events (id, subscription_id, event_type, stripe_event_id, event_data, created_at) FROM stdin;
\.


--
-- Data for Name: subscriptions; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.subscriptions (id, user_id, tier, status, current_period_start, current_period_end, cancel_at, canceled_at, created_at, updated_at, stripe_subscription_id) FROM stdin;
13d974a9-3533-4e70-baad-6fa87986c196	7360cfaa-4de7-4a03-96a7-1aaf317e7874	basic	active	2025-11-09 05:55:39.144976	2025-12-09 05:55:39.144976	\N	\N	2025-11-09 05:55:39.144976	2025-11-09 05:55:39.144976	sub_test_manual
\.


--
-- Data for Name: user_badges; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.user_badges (id, user_id, badge_id, unlocked_at) FROM stdin;
\.


--
-- Data for Name: user_games; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.user_games (id, user_id, game_id, account_name, connected_at, riot_puuid, riot_game_name, riot_tag_line, riot_region, steam_id, verified_at, last_match_check) FROM stdin;
23cfb5ba-35d3-48fe-a670-372b91f84e0b	9dd23b45-ca6c-4b52-bca1-9e531da9bd87	36f728c6-8143-4be3-9e94-54c549a48d7f	JRIP#KUYA	2025-11-12 07:16:20.872972	0P2_3VO6UAbZkMWCUFYS5dDSa2xG9sVOMmfsW7wcVWccgD0r_RCKFn5bBeVJqberkj9AOwDq1yrrvA	JRIP	KUYA	americas	\N	2025-11-12 07:16:20.854	\N
18236da2-f9cb-4ead-8c1b-36a26ebd3d67	bb6009ad-aaf8-4e6c-bbd9-c8b4bedde6d4	4cf0e30a-7969-4572-a8f5-29ad5935dc00	Test User#NA1	2025-11-12 07:45:26.613899	V-iyohD-ONFB7gZCfNMPrD7ztNeX25rU2j3yIG5O1Zuvaq_2buIpFpKsIBg_c5wLjippVLE6NEbDxg	Test User	NA1	na1	\N	2025-11-12 07:45:26.594	\N
\.


--
-- Data for Name: user_rewards; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.user_rewards (id, user_id, reward_id, redeemed_at, status, points_spent, fulfillment_data, tracking_number, fulfillment_notes, fulfilled_at, shipping_address, shipping_city, shipping_state, shipping_zip, shipping_country) FROM stdin;
91184507-b380-41e8-83c0-1593d304d33d	7c229a10-d1bb-453a-9012-bb55ae328e26	d59ec530-5c78-4deb-a8d4-b96424a240df	2025-11-09 09:07:39.253969	pending	50	\N	\N	\N	\N	\N	\N	\N	\N	\N
c846bcb3-ca5d-4b6d-8b46-ad9389527b46	9ebc0fdf-647a-466b-830f-68c709920cc6	d59ec530-5c78-4deb-a8d4-b96424a240df	2025-11-09 09:16:08.58678	pending	50	\N	\N	\N	\N	\N	\N	\N	\N	\N
e74ab046-9bcc-4588-ad38-493094341e8d	5536a6e1-4df0-4d04-94bc-e51903333e3d	d59ec530-5c78-4deb-a8d4-b96424a240df	2025-11-09 09:25:54.343304	pending	50	\N	\N	\N	\N	\N	\N	\N	\N	\N
3081a6a4-0cd3-4ef7-b4ee-a4fd530e2a98	7360cfaa-4de7-4a03-96a7-1aaf317e7874	d59ec530-5c78-4deb-a8d4-b96424a240df	2025-11-09 18:03:10.862062	pending	50	\N	\N	\N	\N	\N	\N	\N	\N	\N
b50d6454-1137-42c1-ac6a-5fcb04d1612e	7360cfaa-4de7-4a03-96a7-1aaf317e7874	4cb55375-3a1f-4fcb-9d62-5b95ffe82354	2025-11-10 03:56:15.977987	pending	100	\N	\N	\N	\N	\N	\N	\N	\N	\N
bf2f3e79-1748-4438-b539-89322dd24ea4	7360cfaa-4de7-4a03-96a7-1aaf317e7874	63210f27-b8ca-4deb-8305-57263e1945c1	2025-11-10 04:01:32.404959	pending	150	\N	\N	\N	\N	\N	\N	\N	\N	\N
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.users (id, email, total_points, games_connected, first_name, last_name, profile_image_url, created_at, updated_at, stripe_customer_id, stripe_subscription_id, oidc_sub, username, twitch_id, twitch_username, twitch_access_token, twitch_refresh_token, twitch_connected_at, referral_code, referred_by, free_trial_started_at, free_trial_ends_at, is_founder, founder_number, gg_coins, login_streak, longest_streak, xp_level, xp_points, last_login_at, shipping_address, shipping_city, shipping_state, shipping_zip, shipping_country) FROM stdin;
9c623996-fd53-4c01-87df-a056e8b9101b	testuser@example.com	500	0	TestGamer	User	\N	2025-11-09 03:40:14.802133	2025-11-09 03:40:14.802133	\N	\N	9c623996-fd53-4c01-87df-a056e8b9101b	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	t	1	0	0	0	1	0	\N	\N	\N	\N	\N	US
922f5e22-cb5e-481d-ab6d-d4e99c131108	testuser2@example.com	1000	0	TestGamer2	User	\N	2025-11-09 03:46:33.605277	2025-11-09 03:46:33.605277	\N	\N	922f5e22-cb5e-481d-ab6d-d4e99c131108	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	t	2	0	0	0	1	0	\N	\N	\N	\N	\N	US
auth-test-sub-001	testauth1@example.com	500	0	Auth	TestUser1	\N	2025-11-09 03:53:12.953037	2025-11-09 03:53:12.953037	\N	\N	auth-test-sub-001	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	t	3	0	0	0	1	0	\N	\N	\N	\N	\N	US
af9d8a41-54cf-4675-88d7-495998768597	authfinal1@example.com	500	0	\N	\N	\N	2025-11-09 03:56:25.109618	2025-11-09 03:56:25.109618	\N	\N	final-test-sub-001	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	t	4	0	0	0	1	0	\N	\N	\N	\N	\N	US
fd495be6-30ea-4545-a322-d22da7a5c186	mvptest@example.com	500	0	\N	\N	\N	2025-11-09 04:00:32.588977	2025-11-09 04:00:32.588977	\N	\N	mvp-test-001	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	t	5	0	0	0	1	0	\N	\N	\N	\N	\N	US
d29f01ad-f80b-4224-bdb3-9531176f335d	final-mvp-test@example.com	500	0	\N	\N	\N	2025-11-09 04:04:44.516699	2025-11-09 04:04:44.516699	\N	\N	final-mvp-sub	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	t	6	0	0	0	1	0	\N	\N	\N	\N	\N	US
c8295c9e-2289-4c6a-ae6c-5e98bd95cd46	mvp-final@example.com	500	0	MVP	Final	\N	2025-11-09 04:06:50.007533	2025-11-09 04:06:50.007533	\N	\N	mvp-final-001	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	t	7	0	0	0	1	0	\N	\N	\N	\N	\N	US
7360cfaa-4de7-4a03-96a7-1aaf317e7874	jaysonquindao1@gmail.com	525	0	Jayson	Quindao	\N	2025-11-09 04:59:13.173145	2025-11-10 04:01:32.585	cus_TODNIc3ltLLhqx	\N	20695111	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	t	8	0	0	0	1	0	\N	\N	\N	\N	\N	US
8196d29c-c28f-45b4-92e3-dd71280c80e1	DLZfLy@example.com	500	0	John	Doe	\N	2025-11-09 08:47:56.044405	2025-11-09 08:47:56.044405	\N	\N	DLZfLy	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	t	9	0	0	0	1	0	\N	\N	\N	\N	\N	US
7c229a10-d1bb-453a-9012-bb55ae328e26	claimtest@example.com	950	0	Claim	Tester	\N	2025-11-09 08:59:45.10534	2025-11-09 09:07:39.438	\N	\N	test-claim-user-CswhD5	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	t	10	0	0	0	1	0	\N	\N	\N	\N	\N	US
b6f2c84a-fbf9-4bb1-a149-0f4516bee175	uifix@example.com	1000	0	UI	Test	\N	2025-11-09 09:12:39.004694	2025-11-09 09:12:39.004694	\N	\N	test-ui-fix-Zttz-d	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	t	11	0	0	0	1	0	\N	\N	\N	\N	\N	US
9ebc0fdf-647a-466b-830f-68c709920cc6	finaltest@example.com	950	0	Final	Tester	\N	2025-11-09 09:15:18.201172	2025-11-09 09:16:08.816	\N	\N	final-test-HHMK_m	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	t	12	0	0	0	1	0	\N	\N	\N	\N	\N	US
4a37262a-a24a-4ea6-a428-89f5dd21c655	secure@example.com	1000	0	Secure	Test	\N	2025-11-09 09:19:35.579576	2025-11-09 09:19:35.579576	\N	\N	secure-test-_KPMgI	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	t	13	0	0	0	1	0	\N	\N	\N	\N	\N	US
5536a6e1-4df0-4d04-94bc-e51903333e3d	securev2@example.com	950	0	Secure	V2	\N	2025-11-09 09:22:04.928962	2025-11-09 09:25:54.523	\N	\N	secure-v2-hEtyrl	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	t	14	0	0	0	1	0	\N	\N	\N	\N	\N	US
2faf28d5-8e2c-47ed-85ff-6c2cc9e832a1	IY3R7b@example.com	500	0	John	Doe	\N	2025-11-09 12:42:41.474893	2025-11-09 12:42:41.474893	\N	\N	IY3R7b	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	t	15	0	0	0	1	0	\N	\N	\N	\N	\N	US
0f9dc7f9-9bb8-4125-9177-7e9da207b740	quindaojayson50@yahoo.com	0	0	jrip0441		https://cdn.discordapp.com/avatars/218205738751885313/1c27e2ca180e5531dfd18216faed294c.png	2025-11-11 22:30:10.231174	2025-11-11 22:30:10.231174	\N	\N	discord:218205738751885313	\N	\N	\N	\N	\N	\N	MD4BC64D	\N	\N	\N	t	16	0	1	1	1	0	2025-11-11 22:30:10.916	\N	\N	\N	\N	US
16d6218b-7695-41df-92b9-220280ec1546	jquindao1@icloud.com	0	0	JRIP	#KUYA	\N	2025-11-12 07:12:37.312401	2025-11-12 07:12:37.312401	\N	\N	\N	guest_20774548	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	0	0	0	1	0	\N	\N	\N	\N	\N	US
9dd23b45-ca6c-4b52-bca1-9e531da9bd87	test@test.com	0	1	JRIP	#KUYA	\N	2025-11-12 07:16:20.798667	2025-11-12 07:16:20.798667	\N	\N	\N	guest_81066446	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	0	0	0	1	0	\N	\N	\N	\N	\N	US
bb6009ad-aaf8-4e6c-bbd9-c8b4bedde6d4	testuser@ggloop.io	0	1	TestUser	#NA1	\N	2025-11-12 07:45:26.517858	2025-11-12 07:45:26.517858	\N	\N	\N	guest_12d8b966	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	0	0	0	1	0	\N	\N	\N	\N	\N	US
\.


--
-- Data for Name: virtual_badges; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.virtual_badges (id, name, description, icon_url, rarity, unlock_condition, gg_coins_required, gg_coins_reward, is_active, created_at) FROM stdin;
badge_streak_7	Week Warrior	Login 7 days in a row	/badges/streak-7.svg	common	streak_7	0	25	t	2025-11-11 05:17:09.295319
badge_streak_30	Monthly Marathoner	Login 30 days in a row	/badges/streak-30.svg	rare	streak_30	0	100	t	2025-11-11 05:17:09.295319
badge_wins_10	First Blood	Win 10 matches	/badges/wins-10.svg	common	wins_10	0	15	t	2025-11-11 05:17:09.295319
badge_wins_50	Rising Star	Win 50 matches	/badges/wins-50.svg	rare	wins_50	0	50	t	2025-11-11 05:17:09.295319
badge_wins_100	Victory Veteran	Win 100 matches	/badges/wins-100.svg	epic	wins_100	0	150	t	2025-11-11 05:17:09.295319
badge_referral_1	Recruiter	Refer your first friend	/badges/referral-1.svg	common	referral_1	0	20	t	2025-11-11 05:17:09.295319
badge_twitch_linked	Streamer	Connected your Twitch account	/badges/twitch.svg	common	twitch_linked	0	10	t	2025-11-11 05:17:09.295319
\.


--
-- Name: achievements achievements_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.achievements
    ADD CONSTRAINT achievements_pkey PRIMARY KEY (id);


--
-- Name: api_partners api_partners_api_key_unique; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.api_partners
    ADD CONSTRAINT api_partners_api_key_unique UNIQUE (api_key);


--
-- Name: api_partners api_partners_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.api_partners
    ADD CONSTRAINT api_partners_pkey PRIMARY KEY (id);


--
-- Name: audit_log audit_log_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.audit_log
    ADD CONSTRAINT audit_log_pkey PRIMARY KEY (id);


--
-- Name: challenge_completions challenge_completions_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.challenge_completions
    ADD CONSTRAINT challenge_completions_pkey PRIMARY KEY (id);


--
-- Name: challenges challenges_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.challenges
    ADD CONSTRAINT challenges_pkey PRIMARY KEY (id);


--
-- Name: checklist_items checklist_items_date_task_id_key; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.checklist_items
    ADD CONSTRAINT checklist_items_date_task_id_key UNIQUE (date, task_id);


--
-- Name: checklist_items checklist_items_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.checklist_items
    ADD CONSTRAINT checklist_items_pkey PRIMARY KEY (id);


--
-- Name: games games_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.games
    ADD CONSTRAINT games_pkey PRIMARY KEY (id);


--
-- Name: gaming_events gaming_events_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.gaming_events
    ADD CONSTRAINT gaming_events_pkey PRIMARY KEY (id);


--
-- Name: gg_coin_transactions gg_coin_transactions_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.gg_coin_transactions
    ADD CONSTRAINT gg_coin_transactions_pkey PRIMARY KEY (id);


--
-- Name: leaderboard_entries leaderboard_entries_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.leaderboard_entries
    ADD CONSTRAINT leaderboard_entries_pkey PRIMARY KEY (id);


--
-- Name: match_submissions match_submissions_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.match_submissions
    ADD CONSTRAINT match_submissions_pkey PRIMARY KEY (id);


--
-- Name: point_transactions point_transactions_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.point_transactions
    ADD CONSTRAINT point_transactions_pkey PRIMARY KEY (id);


--
-- Name: processed_riot_matches processed_riot_matches_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.processed_riot_matches
    ADD CONSTRAINT processed_riot_matches_pkey PRIMARY KEY (id);


--
-- Name: processed_riot_matches processed_riot_matches_riot_account_id_match_id_key; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.processed_riot_matches
    ADD CONSTRAINT processed_riot_matches_riot_account_id_match_id_key UNIQUE (riot_account_id, match_id);


--
-- Name: referrals referrals_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.referrals
    ADD CONSTRAINT referrals_pkey PRIMARY KEY (id);


--
-- Name: referrals referrals_referrer_id_referred_user_id_key; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.referrals
    ADD CONSTRAINT referrals_referrer_id_referred_user_id_key UNIQUE (referrer_id, referred_user_id);


--
-- Name: rewards rewards_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.rewards
    ADD CONSTRAINT rewards_pkey PRIMARY KEY (id);


--
-- Name: riot_accounts riot_accounts_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.riot_accounts
    ADD CONSTRAINT riot_accounts_pkey PRIMARY KEY (id);


--
-- Name: riot_accounts riot_accounts_user_id_game_key; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.riot_accounts
    ADD CONSTRAINT riot_accounts_user_id_game_key UNIQUE (user_id, game);


--
-- Name: sessions sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.sessions
    ADD CONSTRAINT sessions_pkey PRIMARY KEY (sid);


--
-- Name: subscription_events subscription_events_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.subscription_events
    ADD CONSTRAINT subscription_events_pkey PRIMARY KEY (id);


--
-- Name: subscription_events subscription_events_stripe_event_id_unique; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.subscription_events
    ADD CONSTRAINT subscription_events_stripe_event_id_unique UNIQUE (stripe_event_id);


--
-- Name: subscriptions subscriptions_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.subscriptions
    ADD CONSTRAINT subscriptions_pkey PRIMARY KEY (id);


--
-- Name: subscriptions subscriptions_stripe_subscription_id_unique; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.subscriptions
    ADD CONSTRAINT subscriptions_stripe_subscription_id_unique UNIQUE (stripe_subscription_id);


--
-- Name: subscriptions subscriptions_user_id_unique; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.subscriptions
    ADD CONSTRAINT subscriptions_user_id_unique UNIQUE (user_id);


--
-- Name: user_badges user_badges_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.user_badges
    ADD CONSTRAINT user_badges_pkey PRIMARY KEY (id);


--
-- Name: user_badges user_badges_user_id_badge_id_key; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.user_badges
    ADD CONSTRAINT user_badges_user_id_badge_id_key UNIQUE (user_id, badge_id);


--
-- Name: challenge_completions user_challenge_unique; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.challenge_completions
    ADD CONSTRAINT user_challenge_unique UNIQUE (user_id, challenge_id);


--
-- Name: user_games user_games_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.user_games
    ADD CONSTRAINT user_games_pkey PRIMARY KEY (id);


--
-- Name: user_rewards user_rewards_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.user_rewards
    ADD CONSTRAINT user_rewards_pkey PRIMARY KEY (id);


--
-- Name: users users_email_unique; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_email_unique UNIQUE (email);


--
-- Name: users users_oidc_sub_unique; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_oidc_sub_unique UNIQUE (oidc_sub);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: users users_referral_code_key; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_referral_code_key UNIQUE (referral_code);


--
-- Name: users users_stripe_customer_id_unique; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_stripe_customer_id_unique UNIQUE (stripe_customer_id);


--
-- Name: users users_stripe_subscription_id_unique; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_stripe_subscription_id_unique UNIQUE (stripe_subscription_id);


--
-- Name: users users_username_key; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_username_key UNIQUE (username);


--
-- Name: virtual_badges virtual_badges_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.virtual_badges
    ADD CONSTRAINT virtual_badges_pkey PRIMARY KEY (id);


--
-- Name: IDX_session_expire; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX "IDX_session_expire" ON public.sessions USING btree (expire);


--
-- Name: idx_audit_admin; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX idx_audit_admin ON public.audit_log USING btree (admin_user_id);


--
-- Name: idx_audit_target; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX idx_audit_target ON public.audit_log USING btree (target_user_id);


--
-- Name: idx_audit_timestamp; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX idx_audit_timestamp ON public.audit_log USING btree ("timestamp");


--
-- Name: idx_checklist_date; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX idx_checklist_date ON public.checklist_items USING btree (date);


--
-- Name: idx_gaming_events_partner; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX idx_gaming_events_partner ON public.gaming_events USING btree (partner_id);


--
-- Name: idx_gaming_events_status; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX idx_gaming_events_status ON public.gaming_events USING btree (status);


--
-- Name: idx_gaming_events_user; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX idx_gaming_events_user ON public.gaming_events USING btree (user_id);


--
-- Name: idx_gg_coin_tx_user; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX idx_gg_coin_tx_user ON public.gg_coin_transactions USING btree (user_id);


--
-- Name: idx_match_submissions_status; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX idx_match_submissions_status ON public.match_submissions USING btree (status);


--
-- Name: idx_match_submissions_user; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX idx_match_submissions_user ON public.match_submissions USING btree (user_id);


--
-- Name: idx_point_tx_source; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX idx_point_tx_source ON public.point_transactions USING btree (source_type, source_id);


--
-- Name: idx_point_tx_user; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX idx_point_tx_user ON public.point_transactions USING btree (user_id);


--
-- Name: idx_processed_riot_matches_account; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX idx_processed_riot_matches_account ON public.processed_riot_matches USING btree (riot_account_id);


--
-- Name: idx_referrals_referred; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX idx_referrals_referred ON public.referrals USING btree (referred_user_id);


--
-- Name: idx_referrals_referrer; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX idx_referrals_referrer ON public.referrals USING btree (referrer_id);


--
-- Name: idx_riot_accounts_puuid; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX idx_riot_accounts_puuid ON public.riot_accounts USING btree (puuid);


--
-- Name: idx_riot_accounts_user; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX idx_riot_accounts_user ON public.riot_accounts USING btree (user_id);


--
-- Name: unique_riot_puuid_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE UNIQUE INDEX unique_riot_puuid_idx ON public.user_games USING btree (riot_puuid) WHERE (riot_puuid IS NOT NULL);


--
-- Name: users_founder_number_unique; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE UNIQUE INDEX users_founder_number_unique ON public.users USING btree (founder_number) WHERE (founder_number IS NOT NULL);


--
-- Name: achievements achievements_game_id_games_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.achievements
    ADD CONSTRAINT achievements_game_id_games_id_fk FOREIGN KEY (game_id) REFERENCES public.games(id);


--
-- Name: achievements achievements_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.achievements
    ADD CONSTRAINT achievements_user_id_users_id_fk FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: audit_log audit_log_admin_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.audit_log
    ADD CONSTRAINT audit_log_admin_user_id_fkey FOREIGN KEY (admin_user_id) REFERENCES public.users(id);


--
-- Name: audit_log audit_log_target_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.audit_log
    ADD CONSTRAINT audit_log_target_user_id_fkey FOREIGN KEY (target_user_id) REFERENCES public.users(id);


--
-- Name: challenge_completions challenge_completions_challenge_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.challenge_completions
    ADD CONSTRAINT challenge_completions_challenge_id_fkey FOREIGN KEY (challenge_id) REFERENCES public.challenges(id);


--
-- Name: challenge_completions challenge_completions_transaction_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.challenge_completions
    ADD CONSTRAINT challenge_completions_transaction_id_fkey FOREIGN KEY (transaction_id) REFERENCES public.point_transactions(id);


--
-- Name: challenge_completions challenge_completions_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.challenge_completions
    ADD CONSTRAINT challenge_completions_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: challenges challenges_game_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.challenges
    ADD CONSTRAINT challenges_game_id_fkey FOREIGN KEY (game_id) REFERENCES public.games(id);


--
-- Name: gaming_events gaming_events_game_id_games_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.gaming_events
    ADD CONSTRAINT gaming_events_game_id_games_id_fk FOREIGN KEY (game_id) REFERENCES public.games(id);


--
-- Name: gaming_events gaming_events_partner_id_api_partners_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.gaming_events
    ADD CONSTRAINT gaming_events_partner_id_api_partners_id_fk FOREIGN KEY (partner_id) REFERENCES public.api_partners(id);


--
-- Name: gaming_events gaming_events_transaction_id_point_transactions_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.gaming_events
    ADD CONSTRAINT gaming_events_transaction_id_point_transactions_id_fk FOREIGN KEY (transaction_id) REFERENCES public.point_transactions(id);


--
-- Name: gaming_events gaming_events_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.gaming_events
    ADD CONSTRAINT gaming_events_user_id_users_id_fk FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: gg_coin_transactions gg_coin_transactions_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.gg_coin_transactions
    ADD CONSTRAINT gg_coin_transactions_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: leaderboard_entries leaderboard_entries_game_id_games_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.leaderboard_entries
    ADD CONSTRAINT leaderboard_entries_game_id_games_id_fk FOREIGN KEY (game_id) REFERENCES public.games(id);


--
-- Name: leaderboard_entries leaderboard_entries_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.leaderboard_entries
    ADD CONSTRAINT leaderboard_entries_user_id_users_id_fk FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: match_submissions match_submissions_game_id_games_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.match_submissions
    ADD CONSTRAINT match_submissions_game_id_games_id_fk FOREIGN KEY (game_id) REFERENCES public.games(id);


--
-- Name: match_submissions match_submissions_reviewed_by_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.match_submissions
    ADD CONSTRAINT match_submissions_reviewed_by_users_id_fk FOREIGN KEY (reviewed_by) REFERENCES public.users(id);


--
-- Name: match_submissions match_submissions_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.match_submissions
    ADD CONSTRAINT match_submissions_user_id_users_id_fk FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: point_transactions point_transactions_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.point_transactions
    ADD CONSTRAINT point_transactions_user_id_users_id_fk FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: processed_riot_matches processed_riot_matches_riot_account_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.processed_riot_matches
    ADD CONSTRAINT processed_riot_matches_riot_account_id_fkey FOREIGN KEY (riot_account_id) REFERENCES public.riot_accounts(id);


--
-- Name: processed_riot_matches processed_riot_matches_transaction_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.processed_riot_matches
    ADD CONSTRAINT processed_riot_matches_transaction_id_fkey FOREIGN KEY (transaction_id) REFERENCES public.point_transactions(id);


--
-- Name: referrals referrals_referred_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.referrals
    ADD CONSTRAINT referrals_referred_user_id_fkey FOREIGN KEY (referred_user_id) REFERENCES public.users(id);


--
-- Name: referrals referrals_referrer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.referrals
    ADD CONSTRAINT referrals_referrer_id_fkey FOREIGN KEY (referrer_id) REFERENCES public.users(id);


--
-- Name: riot_accounts riot_accounts_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.riot_accounts
    ADD CONSTRAINT riot_accounts_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: subscription_events subscription_events_subscription_id_subscriptions_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.subscription_events
    ADD CONSTRAINT subscription_events_subscription_id_subscriptions_id_fk FOREIGN KEY (subscription_id) REFERENCES public.subscriptions(id);


--
-- Name: subscriptions subscriptions_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.subscriptions
    ADD CONSTRAINT subscriptions_user_id_users_id_fk FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: user_badges user_badges_badge_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.user_badges
    ADD CONSTRAINT user_badges_badge_id_fkey FOREIGN KEY (badge_id) REFERENCES public.virtual_badges(id);


--
-- Name: user_badges user_badges_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.user_badges
    ADD CONSTRAINT user_badges_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: user_games user_games_game_id_games_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.user_games
    ADD CONSTRAINT user_games_game_id_games_id_fk FOREIGN KEY (game_id) REFERENCES public.games(id);


--
-- Name: user_games user_games_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.user_games
    ADD CONSTRAINT user_games_user_id_users_id_fk FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: user_rewards user_rewards_reward_id_rewards_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.user_rewards
    ADD CONSTRAINT user_rewards_reward_id_rewards_id_fk FOREIGN KEY (reward_id) REFERENCES public.rewards(id);


--
-- Name: user_rewards user_rewards_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.user_rewards
    ADD CONSTRAINT user_rewards_user_id_users_id_fk FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: users users_referred_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_referred_by_fkey FOREIGN KEY (referred_by) REFERENCES public.users(id);


--
-- Name: DEFAULT PRIVILEGES FOR SEQUENCES; Type: DEFAULT ACL; Schema: public; Owner: cloud_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE cloud_admin IN SCHEMA public GRANT ALL ON SEQUENCES TO neon_superuser WITH GRANT OPTION;


--
-- Name: DEFAULT PRIVILEGES FOR TABLES; Type: DEFAULT ACL; Schema: public; Owner: cloud_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE cloud_admin IN SCHEMA public GRANT ALL ON TABLES TO neon_superuser WITH GRANT OPTION;


--
-- PostgreSQL database dump complete
--

